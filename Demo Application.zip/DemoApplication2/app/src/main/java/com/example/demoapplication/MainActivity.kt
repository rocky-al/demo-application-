package com.example.demoapplication

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.google.android.material.textfield.TextInputEditText
import org.w3c.dom.Text

class MainActivity : AppCompatActivity() {

    var loginBtn : TextView?=null
    var useName : TextInputEditText? = null
    var usePassword : TextInputEditText? = null
    var REQUEST_LOCATION : Int? = 1212

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        loginBtn = findViewById(R.id.tv_login_btn)
        useName = findViewById(R.id.ed_user_name)
        usePassword = findViewById(R.id.ed_user_password)

        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this,
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION),
                REQUEST_LOCATION!!)

        }

        if( !getUserDetails().equals("")){
            startActivity(Intent(this,HomeAtivity::class.java))
        }


        loginBtn!!.setOnClickListener {

            var userNameStr = useName!!.text.toString().trim()
            var userPasswordStr = usePassword!!.text.toString().trim()



            if(!userNameStr.equals("") && !userPasswordStr.equals("")){
                val prefs = getSharedPreferences("DemoApp", Context.MODE_PRIVATE)
                val edit = prefs.edit()
                edit.putString("userName", userNameStr)
                edit.putString("userPassword", userPasswordStr)
                edit.commit()
                startActivity(Intent(this,HomeAtivity::class.java))

            }else{
                Toast.makeText(this,"Fill All Details..",Toast.LENGTH_SHORT).show()
            }


        }


    }


   fun getUserDetails() : String{

       val prefs = getSharedPreferences("DemoApp", Context.MODE_PRIVATE)
       return prefs.getString("userName", "")!!
    }
}