package com.example.demoapplication

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContentProviderCompat.requireContext
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.tasks.OnCompleteListener
import java.io.*


class HomeAtivity : AppCompatActivity() {

    var fusedLocationProviderClient: FusedLocationProviderClient? = null
    var startButton : Button?= null
    var showButton : Button?= null
    var locationSettingCode : Int?= 2311
    var REQUEST_LOCATION : Int?= 2343

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(com.example.demoapplication.R.layout.activity_home_ativity)

        startButton = findViewById(R.id.start_button)
        showButton = findViewById(R.id.show_data)
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this,
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION),
                REQUEST_LOCATION!!)

        }


        startButton!!.setOnClickListener {
            val handler = Handler()

            val runnableCode: Runnable = object : Runnable {
                override fun run() {
                    // Do something here on the main thread
                    sendKycRequest()
                    // Repeat this the same runnable code block again another 2 seconds
                    // 'this' is referencing the Runnable object
                    handler.postDelayed(this, 300000)
                }
            }

            handler.post(runnableCode)

        }

        showButton!!.setOnClickListener {
            startActivity(Intent(this,ReadData::class.java))
        }


    }
    private fun readFromFile(context: Context): String? {
        var ret = ""
        try {
            val inputStream: InputStream = context.openFileInput("config.txt")
            if (inputStream != null) {
                val inputStreamReader = InputStreamReader(inputStream)
                val bufferedReader = BufferedReader(inputStreamReader)
                var receiveString: String? = ""
                val stringBuilder = StringBuilder()
                while (bufferedReader.readLine().also { receiveString = it } != null) {
                    stringBuilder.append("\n").append(receiveString)
                }
                inputStream.close()
                ret = stringBuilder.toString()
            }
        } catch (e: FileNotFoundException) {
            Log.e("login activity", "File not found: " + e.toString())
        } catch (e: IOException) {
            Log.e("login activity", "Can not read file: " + e.toString())
        }
        return ret
    }


    private fun writeToFile(data: String, context: Context) {
        try {
            val outputStreamWriter =
                OutputStreamWriter(context.openFileOutput("config.txt", MODE_PRIVATE))
            outputStreamWriter.append(data)
            outputStreamWriter.close()
        } catch (e: IOException) {
            Log.e("Exception", "File write failed: " + e.toString())
        }






    }

    fun sendKycRequest() {


        var latituteStr: String? = null
        var longituteStr: String? = null

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)

        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
        } else {
            fusedLocationProviderClient!!.lastLocation.addOnCompleteListener(OnCompleteListener {
                var location: Location = it.getResult()
                if (location != null) {
                    latituteStr = location.latitude.toString()
                    longituteStr = location.longitude.toString()

                    Toast.makeText(this,latituteStr+","+longituteStr,Toast.LENGTH_SHORT).show()

                    writeToFile(readFromFile(this).toString()+"\n"+latituteStr+","+longituteStr,this)

                }
            })

        }

    }

    override fun onStart() {
        super.onStart()
        checkGoogleLocation()
    }

    fun checkGoogleLocation() {
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var gps_enabled = false
        var network_enabled = false

        try {
            gps_enabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
        } catch (ex: Exception) {
        }

        try {
            network_enabled = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
        } catch (ex: Exception) {
        }

        if (!gps_enabled && !network_enabled) {
            // notify user
            AlertDialog.Builder(this)
                .setMessage("Google location Permisition")
                .setPositiveButton("Yes",
                    DialogInterface.OnClickListener { paramDialogInterface, paramInt ->
                        startActivityForResult(Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS),
                            locationSettingCode!!)
                    })
                .setNegativeButton("Cancel", { paramDialogInterface, paramInt ->
                    finish()
                })
                .show()
        }
    }


}